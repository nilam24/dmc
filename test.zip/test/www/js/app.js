angular.module('test',["test.controller","ngRoute"])
.config(function($routeProvider){

$routeProvider
.when("/",{ templateUrl:"template/home.htm"})


.when("/entryform",{templateUrl:"template/entryform.htm" , controller:"entryctrl"})
.when("/placeform",{templateUrl:"template/placeform.htm" , controller:"placectrl"})




})
