angular.module("test.controller",[])
.controller('entryctrl',function($scope){




var array={'countrycode':$scope.countrycode,'phone':$scope.phone};
var countrycode=String(countrycode);

var error=$scope.error;
$scope.searchText  = "+";


 $scope.myModel = {};
  $scope.Prompt="input code here";


          // function MyCntl($scope) {

    $scope.myPrompt = "Input your phonenumber here!";


   $scope.submitVal= function(){

                var inputNumber;
                var phoneNum;
			    var  value1=String(value1);
                var value2=String(value2);
                var number1,number2;

                 $scope.number1=value1.replace(/[^0-9]+/g, '');

                $scope.number2=value2.replace(/[^0-9]+/g, '')

                if($scope.number1==null || $scope.number2==null)
                {
                    alert("plz entre valid number");
                }


                 if($scope.number1!=null){

			var c = ($scope.number1[0] == '1') ? '1 ' : '';
			$scope.number1 = $scope.number1[0] == '1' ? $scope.number1.slice(1) : $scope.number1;

                 number1=String(number1);

                inputNumber=number1;
                $scope.countrycode=number1;
                  var n = number1.substring(0,4);


             	if(n)
                 {
                    $scope.inputNumber=($scope.searchText + n);
				    $scope.countrycode=$scope.inputNumber;

               			}
                else{
                          $scope.error="invalid";
                      }


              return $scope.countrycode;

            }
            else{
                $scope.error="invalid";
            }



             if($scope.number2!=null){

			var d = ($scope.number2[0] == '1') ? '1 ' : '';
			$scope.number2=$scope.number2[0] == '1' ? $scope.number2.slice(1) : $scope.number2;

                            var number2=String(number2);
                               phoneNum=number2;
                			var phoneNumber = number2.substring(0,10);

      			if(phoneNumber) {

				phoneNum=""+phoneNumber;
                 $scope.phone=$scope.phoneNum;

    			}
                $scope.error="invalid";

             return $scope.phone;

            }

            else{
                $scope.error="invalid";
            }


                document.getElementById('countrycode').innerHTML="+"+$scope.countrycode;
                 document.getElementById('phone').innerHTML=$scope.phone;

               //  return $scope.countrycode+""+$scope.phone;
             }




          })






.controller('placectrl',function($scope){
//    $scope.customers=angular.fromJson(window.localStorage['members19']);
    alert("place within pune city");

    


      distance=String(distance);

     temperature=String(temperature);
    $scope.distance=12;
    $scope.temperature=15;





})

