package in.cdac.day19fcmdemo056;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;


/**
 * Created by Dell1 on 14/01/2018.
 */

public class DisplaySearchResultActivity extends AppCompatActivity {

    TextView label;
    ListView listViewResult;
    AdapterBookSearchResult adapterBookSearchResult;
    ArrayList<BookInfo> arraylist=null;
    BookInfo bookInfo;
    public final String TAG=DisplaySearchResultActivity.this.getClass().getName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.list_search_info_layout);

            Intent in=getIntent();
            Bundle b=in.getExtras();

            if(b!=null) {

                         arraylist = b.getParcelableArrayList("bookinfo");
                        }

                         bookInfo=new BookInfo();


                         label=(TextView)findViewById(R.id.textViewSearchBy);
                         label.setText("search by  ");

            if(arraylist==null)
            {
                            return;

             }

            if(arraylist!=null) {

                          adapterBookSearchResult = new AdapterBookSearchResult(DisplaySearchResultActivity.this, arraylist);

                    }
                           listViewResult=(ListView)findViewById(R.id.listviewId);
                           listViewResult.setAdapter(adapterBookSearchResult);
                           adapterBookSearchResult.notifyDataSetChanged();

                           Log.e(TAG,"in arraylist =="+arraylist+" ");

    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onRestart() {
        super.onRestart();

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        bookInfo=new BookInfo();
        arraylist=new ArrayList<>();
        listViewResult.setAdapter(adapterBookSearchResult);
        adapterBookSearchResult.notifyDataSetChanged();

    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        listViewResult.setAdapter(adapterBookSearchResult);
        adapterBookSearchResult.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
