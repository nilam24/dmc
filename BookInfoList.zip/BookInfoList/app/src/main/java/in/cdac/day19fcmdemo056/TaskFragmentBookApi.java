package in.cdac.day19fcmdemo056;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Dell1 on 23/01/2018.
 */

public class TaskFragmentBookApi extends Fragment {


    public final String TAG=TaskFragmentBookApi.class.getName();
    SharedPreferences preferences;
    public static final String mypreferences = "in.cdac.day19fcmdemo056.MyPreferences";
    String baseQuery="https://www.googleapis.com/books/v1/volumes?q=";
    String query;


        interface Taskcallbacks {

                void onPreExecute();

                void onProgressupdate(Void percent);

                void onCancelled();

                void onPostExecute();

         }

    private Taskcallbacks mcallbacks;
    private TaskForSearchBooks taskForSearchBooks;


    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);
                mcallbacks= (Taskcallbacks) getActivity();

    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

                setRetainInstance(true);

                try {
                      Bundle bundle = this.getArguments();

                      query = bundle.getString("useQuery");

                      URL url = null;
                try {
                      Uri uri = urlEncode(query);
                      url = createUrl(uri);
                } catch (UnsupportedEncodingException e) {
                      e.printStackTrace();
                    }

                    taskForSearchBooks = new TaskForSearchBooks();
                    taskForSearchBooks.execute(url);
                }catch(NullPointerException n)
                    {
                        String mesg=n.getLocalizedMessage();
                        Log.e(TAG,"mesg fragment"+mesg);
                    }
     }


    @Override
    public void onDetach() {
        super.onDetach();

            mcallbacks=null;

    }


    private Uri urlEncode(String qq) throws UnsupportedEncodingException {

            String querySearchCriteria = URLEncoder.encode(qq, "UTF-8");
            String  newGoogleBookApiqueryUrl = baseQuery + querySearchCriteria;
            Uri builtUri = Uri.parse(newGoogleBookApiqueryUrl)
                            .buildUpon()
                            .appendQueryParameter("maxResult", "3")
                            .build();

            return builtUri;

        }

    private URL createUrl(Uri uri) {

            URL url = null;

            try {

                url = new URL(uri.toString());

                return url;

              } catch (MalformedURLException e) {
                    e.printStackTrace();

                 }

               return url;

       }


    private class TaskForSearchBooks extends AsyncTask<URL, Void, String> {

                HashMap<String,BookInfo> bookInfoHashMap=new HashMap<>();
                HttpsURLConnection connection=null;
                BookInfo bookInfo;
                InputStream inputStream=null;

         public TaskForSearchBooks (){}


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

             if(mcallbacks!=null)
                {
                    mcallbacks.onPreExecute();
                }
            }

        @Override
        protected String doInBackground(URL... urls) {

                int i=0;

                for(i=0;isCancelled()&&i<100;i++)
                {
                     SystemClock.sleep(100);
                     publishProgress();
                }

                    URL url=urls[0];
                    URL smallThumbnail;

                    String res = null;
                    Bitmap bitmap;

                try {
                    res = makeConnection(url);
                    Log.e(TAG, "=" + res);

                  } catch (Exception e) {
                        e.printStackTrace();
                  }

                try {

                    bookInfoHashMap = extractJsonBookInfo(res);

                 } catch (JSONException e) {
                        e.printStackTrace();

                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

            if(bookInfoHashMap!=null) {

                                res = "success";

                       }

                    Log.e(TAG,"="+bookInfoHashMap);

                    return res;

                }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);

                  if(mcallbacks!=null)
                    {
                        mcallbacks.onProgressupdate(values[0]);
                    }

            }


        @Override
        protected void onCancelled() {
            super.onCancelled();
                  if(mcallbacks!=null)
                        {
                            mcallbacks.onCancelled();
                        }
            }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

                  if(mcallbacks!=null)
                    {
                        mcallbacks.onPostExecute();
                    }

                    if(s==null)
                    {
                        return;
                    }

                    if((s!=null)&&(s.equalsIgnoreCase("success"))) {

                        Intent intent = new Intent(getContext(), DisplaySearchResultActivity.class);

                        ArrayList<BookInfo> bookInfoslist = new ArrayList<>();

                        if(bookInfoHashMap!=null)

                        {

                            Iterator iterator=bookInfoHashMap.entrySet().iterator();

                            while (iterator.hasNext())

                            {
                                Map.Entry entry= (Map.Entry) iterator.next();

                                bookInfo= (BookInfo) entry.getValue();

                                bookInfoslist.add(bookInfo);

                                preferences=getActivity().getSharedPreferences(mypreferences, Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor= preferences.edit();
                                editor.putString("title", bookInfo.getTitle());
                                editor.putString("authors",bookInfo.getAuthors());
                                editor.putString("publisher",bookInfo.getPublisher());
                                editor.apply();

                                Log.e(TAG,"pref value="+editor+" "+preferences.toString());

                                Log.e(TAG,"postexecute"+bookInfoslist);

                            }

                        }

                        Bundle bundle = new Bundle();

                        bundle.putParcelableArrayList("bookinfo", bookInfoslist);

                        bundle.putAll(bundle);

                        intent.putExtras(bundle);

                        startActivity(intent);

                  }

         }

         private String makeConnection(URL url) throws IOException {

             String jsonResult = "";
             Bitmap bitmap;

             if (url == null) {

                return jsonResult;

             }

            try {
                  connection = (HttpsURLConnection) url.openConnection();
                  connection.setRequestMethod("GET");
                  connection.setReadTimeout(10000);
                  connection.setConnectTimeout(15000);
                  connection.connect();

                if (connection.getResponseCode() == 200) {

                    inputStream = connection.getInputStream();
                    jsonResult = readFromStream(inputStream);
                    readFromStream(inputStream);


                } else

                    Log.e(TAG, "" + connection.getResponseCode());

                } catch (IOException io) {

                        io.printStackTrace();

                    } finally {
                            if (connection != null) {
                                    connection.disconnect();
                            }
                            if (inputStream != null) {
                                    inputStream.close();
                              }

                         }

                        Log.e(TAG, "httpConnection " + jsonResult);


             return jsonResult;

         }

        private String readFromStream(InputStream inputStream) throws IOException {
               StringBuilder builder = new StringBuilder();

               Bitmap bitmap;
               if (inputStream != null) {

                        InputStreamReader reader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                        BufferedReader bufferedReader = new BufferedReader(reader);
                        String line = bufferedReader.readLine();

                        while (line != null) {

                            builder.append(line);
                            line = bufferedReader.readLine();



                        }

               }

                Log.e(TAG, " " + builder);

               return builder.toString();
        }

        private HashMap<String, BookInfo> extractJsonBookInfo(String jsonString) throws JSONException, UnsupportedEncodingException {

            BookInfo info = null;
            String booktitle=null;
            String authorname = null;
            String publishername = null;
            String imglink,imgsplit;

            HashMap<String, BookInfo> mapbookinfo = new HashMap<>();

            if (TextUtils.isEmpty(jsonString)) {

                return null;
            }

            try {
                JSONObject rootJson = new JSONObject(jsonString);
                JSONArray itemarray = rootJson.getJSONArray("items");
                int i = 0;
                for (i = 0; i < itemarray.length(); i++) {
                    JSONObject itemroot = itemarray.getJSONObject(i);

                    JSONObject volumeobj = itemroot.getJSONObject("volumeInfo");

                    booktitle = volumeobj.getString("title");

                         if (volumeobj.has("authors")) {
                            JSONArray authorarray = volumeobj.getJSONArray("authors");

                                for (int j = 0; j < authorarray.length(); j++) {
                                authorname = authorarray.optString(j);

                                        }

                                }

                         if (volumeobj.has("publisher")) {

                                publishername = volumeobj.getString("publisher");

                                }

                     JSONObject imagelinkobj = volumeobj.getJSONObject("imageLinks");

                       imglink = (String) imagelinkobj.get("smallThumbnail");

                       imgsplit = imglink.split(",")[0];
                       byte[] img=imgsplit.getBytes("UTF-8");
                       BitmapFactory.Options opt=new BitmapFactory.Options();
                       opt.inJustDecodeBounds=true;
                       opt.inMutable=true;
                       opt.outWidth=0;

                       Bitmap bitmap=BitmapFactory.decodeByteArray(img,0,img.length,opt);

                       Log.e("TAG","bitmap value"+bitmap);

                     info = new BookInfo(booktitle, authorname, publishername,bitmap);
                        mapbookinfo.put(booktitle, info);

                    Log.e(TAG, ": mapbookinfo" + mapbookinfo.size());

                }

             } catch (JSONException e) {
                e.printStackTrace();
                }

            return mapbookinfo;
        }


    }
}