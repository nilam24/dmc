package in.cdac.day19fcmdemo056;


import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Dell1 on 14/01/2018.
 */

public class BookInfo implements Parcelable{

                 public String title;
                 public String authors;
                 public String publisher;
                 public Bitmap smallThumbnails;

    public  BookInfo(){}

    public BookInfo(Parcel parcel) {
                title = parcel.readString();
                authors = parcel.readString();
                publisher = parcel.readString();
                smallThumbnails=parcel.readParcelable(ClassLoader.getSystemClassLoader());
    }

    public BookInfo(String title, String authors, String publisher) {
                this.title = title;
                this.authors = authors;
                this.publisher = publisher;
    }

    public BookInfo(String title, String authors, String publisher, Bitmap smallThumbnails) {
        this.title = title;
        this.authors = authors;
        this.publisher = publisher;
        this.smallThumbnails = smallThumbnails;
    }

    public static final Creator<BookInfo> CREATOR = new Creator<BookInfo>() {
        @Override
        public BookInfo createFromParcel(Parcel in) {
            return new BookInfo(in);
        }

        @Override
        public BookInfo[] newArray(int size) {
            return new BookInfo[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public Bitmap getSmallThumbnails() {
        return smallThumbnails;
    }

    public void setSmallThumbnails(Bitmap smallThumbnails) {
                    this.smallThumbnails = smallThumbnails;
    }

    @Override
    public String toString() {
            return "BookInfo{" +
                    "title='" + title + '\'' +
                    ", authors='" + authors + '\'' +
                    ", publisher='" + publisher + '\'' +
                    ", smallThumbnails='" + smallThumbnails +
                    '}';
     }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

                  parcel.writeString(title);
                  parcel.writeString(authors);
                  parcel.writeString(publisher);
                  parcel.writeParcelable(smallThumbnails,Parcelable.PARCELABLE_WRITE_RETURN_VALUE);

        }

    public static final Parcelable.Creator creator= new Creator() {

        @Override
        public BookInfo createFromParcel(Parcel parcel) {
            return new BookInfo(parcel);
        }


        @Override
          public BookInfo[] newArray(int i) {
            return new BookInfo[i];
        }

    };

}
