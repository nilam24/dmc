package in.cdac.day19fcmdemo056;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PersistableBundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



/**
 * Created by Dell1 on 14/01/2018.
 */


public class MainActivity extends AppCompatActivity  implements TaskFragmentBookApi.Taskcallbacks{

    TextView label;
    EditText editText;
    Button click;
    String searchtext, userQuery;
    String API_KEY="AIzaSyAKnS_-JxZo9sPyNnwIDX-jSGyrJvIYSTs";
    SharedPreferences preferences;
    public static final String mypreferences = "in.cdac.day19fcmdemo056.MyPreferences";
    BookInfo bookInfo;
    public final String TAG = MainActivity.this.getClass().getName();
    String error;
    String title_key=null;
    private static final String TAG_TASK_FRAGMENT="task_fragment";
    private TaskFragmentBookApi taskFragmentBookApi;
    FragmentManager fragmentManager;


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        label = (TextView) findViewById(R.id.textViewSearchCriteria);
        editText = (EditText) findViewById(R.id.editTextSearch);
        click = (Button) findViewById(R.id.buttonSearch);

        label.setVisibility(View.GONE);

        bookInfo = new BookInfo();


        final int REQUEST_INTERNET_PERMISSION = 1;

        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET);

            if (Build.VERSION.SDK_INT >= 23) {
                if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, REQUEST_INTERNET_PERMISSION);

                     }
            } else
                    System.out.println("internet permission is granted automatically");



            preferences = getApplicationContext().getSharedPreferences(mypreferences, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=preferences.edit();

            editor.putString("userQuery",searchtext);
            editor.apply();


            preferences=getSharedPreferences(mypreferences,Context.MODE_PRIVATE);
                if (preferences != null) {
                    Log.e("preference has values", "size" + preferences.getString("title", ""));

                         title_key=preferences.getString("userQuery","");

            }


            fragmentManager=getSupportFragmentManager();
            taskFragmentBookApi=(TaskFragmentBookApi) fragmentManager.findFragmentByTag(TAG_TASK_FRAGMENT);
            taskFragmentBookApi = new TaskFragmentBookApi();



            click.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                        label.setVisibility(View.VISIBLE);

                        searchtext = editText.getText().toString().trim();

                        try {
                            if (searchtext == null) {
                                return;

                            } else {
                            userQuery = searchtext.replaceAll(" ", "+");

                            Log.e(TAG, ":=: " + userQuery);

                            taskFragmentBookApi = new TaskFragmentBookApi();
                            Intent intent = new Intent(MainActivity.this, TaskFragmentBookApi.class);
                            Bundle bundle = new Bundle();

                            bundle.putString("useQuery", userQuery);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                            taskFragmentBookApi.setArguments(bundle);
                            FragmentTransaction transaction=fragmentManager.beginTransaction();
                            transaction.add(taskFragmentBookApi,TAG_TASK_FRAGMENT);
                            transaction.commit();

                            }
                        }

                      catch (NullPointerException n)
                        {
                            error=n.getMessage();
                            Log.e(TAG,"error=="+error);
                        }


              }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onRestart() {
        super.onRestart();

    }

    @Override
    protected void onResume() {
        super.onResume();

            bookInfo = new BookInfo();

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
         super.onSaveInstanceState(outState);
            searchtext = editText.getText().toString().trim();
            outState.putString("userQuery", searchtext);
            click.setVisibility(View.VISIBLE);

        }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState, PersistableBundle persistentState) {
          super.onRestoreInstanceState(savedInstanceState, persistentState);

             String text = savedInstanceState.getString("userQuery");

        }

    @Override
    public Object onRetainCustomNonConfigurationInstance() {

            if (bookInfo != null) {
                return bookInfo;
            }


            return super.onRetainCustomNonConfigurationInstance();
        }

    @Override
    protected void onStop() {
           super.onStop();

        }

    @Override
        protected void onDestroy() {
            super.onDestroy();

        }

    @Override
    public void onPreExecute() {

    }

    @Override
    public void onProgressupdate(Void percent) {

    }

    @Override
    public void onCancelled() {

    }

    @Override
    public void onPostExecute() {

    }
}